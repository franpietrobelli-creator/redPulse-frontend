import { Component } from '@angular/core';

@Component({
  selector: 'app-bolsas-listagem',
  standalone: true,
  templateUrl: './bolsas-listagem.html',
  styleUrl: './bolsas-listagem.css'
})
export class BolsasListagemComponent {}