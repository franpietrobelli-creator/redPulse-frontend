import { Component } from '@angular/core';

@Component({
  selector: 'app-sangue',
  standalone: true,
  templateUrl: './sangue.html',
  styleUrl: './sangue.css'
})
export class SangueComponent {}